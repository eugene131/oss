when app.py play, practice.html play
change only page1.html
not just play practice.html only with app.py
