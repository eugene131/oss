#__init__.py

from .testInput import *
from .testsearch import *
